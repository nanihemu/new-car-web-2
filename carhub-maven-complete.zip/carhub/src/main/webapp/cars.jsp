<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <title>CarHub - Cars</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/styles.css">
</head>
<body>
<h1>CarHub Cars</h1>

<form method="post" action="${pageContext.request.contextPath}/cars/add">
    <input name="brand" placeholder="Brand" required>
    <input name="model" placeholder="Model" required>
    <input name="year" type="number" placeholder="Year" required>
    <input name="price" type="number" step="0.01" placeholder="Price" required>
    <input name="fuelType" placeholder="Fuel type">
    <input name="transmission" placeholder="Transmission">
    <input name="imageUrl" placeholder="Image URL">
    <button type="submit">Add Car</button>
</form>

<table>
<tr><th>Brand</th><th>Model</th><th>Year</th><th>Price</th><th>Action</th></tr>
<c:forEach var="car" items="${cars}">
<tr>
<td>${car.brand}</td><td>${car.model}</td><td>${car.year}</td><td>${car.price}</td>
<td>
<form method="post" action="${pageContext.request.contextPath}/cars/delete">
<input type="hidden" name="id" value="${car.id}">
<button type="submit">Delete</button>
</form>
</td>
</tr>
</c:forEach>
</table>
</body>
</html>
