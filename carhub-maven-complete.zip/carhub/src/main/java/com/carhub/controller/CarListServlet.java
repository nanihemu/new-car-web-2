package com.carhub.controller;

import com.carhub.service.CarService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/cars")
public class CarListServlet extends HttpServlet {
    private final CarService service = new CarService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            req.setAttribute("cars", service.getAllCars());
            req.getRequestDispatcher("/cars.jsp").forward(req, resp);
        } catch (Exception e) {
            throw new ServletException("Unable to load cars", e);
        }
    }
}
