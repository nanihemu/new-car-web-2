package com.carhub.controller;

import com.carhub.model.Car;
import com.carhub.service.CarService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/cars/add")
public class CarAddServlet extends HttpServlet {
    private final CarService service = new CarService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            Car car = new Car();
            car.setBrand(req.getParameter("brand"));
            car.setModel(req.getParameter("model"));
            car.setYear(Integer.parseInt(req.getParameter("year")));
            car.setPrice(Double.parseDouble(req.getParameter("price")));
            car.setFuelType(req.getParameter("fuelType"));
            car.setTransmission(req.getParameter("transmission"));
            car.setImageUrl(req.getParameter("imageUrl"));
            service.addCar(car);
            resp.sendRedirect(req.getContextPath() + "/cars");
        } catch (Exception e) {
            throw new ServletException("Unable to add car", e);
        }
    }
}
