package com.carhub.controller;

import com.carhub.service.CarService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/cars/delete")
public class CarDeleteServlet extends HttpServlet {
    private final CarService service = new CarService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            service.deleteCar(Integer.parseInt(req.getParameter("id")));
            resp.sendRedirect(req.getContextPath() + "/cars");
        } catch (Exception e) {
            throw new ServletException("Unable to delete car", e);
        }
    }
}
