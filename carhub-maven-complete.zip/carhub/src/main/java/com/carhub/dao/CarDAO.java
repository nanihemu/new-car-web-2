package com.carhub.dao;

import com.carhub.model.Car;
import com.carhub.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CarDAO {
    public List<Car> findAll() throws SQLException {
        List<Car> cars = new ArrayList<>();
        String sql = "SELECT id, brand, model, year, price, fuel_type, transmission, image_url FROM cars ORDER BY id DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                cars.add(map(rs));
            }
        }
        return cars;
    }

    public Car findById(int id) throws SQLException {
        String sql = "SELECT id, brand, model, year, price, fuel_type, transmission, image_url FROM cars WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    public void save(Car car) throws SQLException {
        String sql = "INSERT INTO cars(brand, model, year, price, fuel_type, transmission, image_url) VALUES(?,?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, car.getBrand());
            ps.setString(2, car.getModel());
            ps.setInt(3, car.getYear());
            ps.setDouble(4, car.getPrice());
            ps.setString(5, car.getFuelType());
            ps.setString(6, car.getTransmission());
            ps.setString(7, car.getImageUrl());
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM cars WHERE id=?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    private Car map(ResultSet rs) throws SQLException {
        return new Car(
            rs.getInt("id"), rs.getString("brand"), rs.getString("model"),
            rs.getInt("year"), rs.getDouble("price"), rs.getString("fuel_type"),
            rs.getString("transmission"), rs.getString("image_url")
        );
    }
}
