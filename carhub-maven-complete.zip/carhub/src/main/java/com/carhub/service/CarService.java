package com.carhub.service;

import com.carhub.dao.CarDAO;
import com.carhub.model.Car;
import java.sql.SQLException;
import java.util.List;

public class CarService {
    private final CarDAO carDAO = new CarDAO();

    public List<Car> getAllCars() throws SQLException {
        return carDAO.findAll();
    }

    public Car getCar(int id) throws SQLException {
        return carDAO.findById(id);
    }

    public void addCar(Car car) throws SQLException {
        carDAO.save(car);
    }

    public void deleteCar(int id) throws SQLException {
        carDAO.delete(id);
    }
}
