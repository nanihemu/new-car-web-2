# CarHub - Maven WAR CI/CD Project

CarHub is a simple car e-commerce web application designed for a Jenkins + Maven + Nexus + Tomcat lab.

## Folder structure

```text
carhub/
├── .github/
│   └── workflows/
├── src/
│   └── main/
│       └── webapp/
│           ├── WEB-INF/
│           │   └── web.xml
│           ├── index.jsp
│           ├── script.js
│           └── styles.css
├── Dockerfile
├── Jenkinsfile
├── pom.xml
├── tomcat-users.xml
└── README.md
```

The structure intentionally follows the supplied reference repository's Maven WAR layout:
`src/main/webapp`, `WEB-INF`, `index.jsp`, `script.js`, `styles.css`, plus root `pom.xml` and `Jenkinsfile`.

## Local build

```bash
mvn clean package
```

WAR output:

```text
target/carhub.war
```

## Tomcat

Copy `target/carhub.war` into Tomcat's `webapps/` directory.

Then open:

```text
http://SERVER-IP:8080/carhub/
```

If renamed to ROOT.war, use:

```text
http://SERVER-IP:8080/
```

## Nexus

Create these Maven hosted repositories:

- `cars-release`
- `cars-snapshot`

For a release:

```bash
mvn deploy -Dnexus.url=http://NEXUS-IP:8081
```

Configure credentials in Maven `settings.xml` using the IDs:

- `nexus-releases`
- `nexus-snapshots`

Do not put real Nexus passwords in `pom.xml` or Jenkinsfile.

## Jenkins

Recommended pipeline:

1. Jenkins checks out Git.
2. Maven runs `clean package`.
3. WAR is created as `target/carhub.war`.
4. Maven deploy publishes the WAR to Nexus.
5. A deployment step copies/downloads the WAR from Nexus to Tomcat.

The supplied Jenkinsfile intentionally keeps credentials out of source control.

## Application features

- Car catalogue
- Search
- Brand/category filtering
- Budget filtering
- Sort by price
- Car details modal
- Add-to-cart counter
- Responsive UI
- No database required for the lab

This makes the application easy to build repeatedly while practicing CI/CD.
