# CarHub - Maven/Tomcat Structure

## Maven structure

src/main/java/com/carhub/
- controller
- dao
- model
- service
- util

src/main/resources/
- application.properties
- schema.sql

src/main/webapp/
- JSP pages
- CSS/JS
- WEB-INF/web.xml

## Build

mvn clean package

The WAR will be generated as:
target/carhub.war

## Database

1. Install MySQL.
2. Run `src/main/resources/schema.sql`.
3. Update `src/main/resources/application.properties` or `DBConnection.java` if your MySQL credentials differ.
4. Deploy `target/carhub.war` to Tomcat 10.1+.

The Java backend included here provides a basic Car model, JDBC DAO, service layer and servlet CRUD endpoints.
